function reverseDate(x){
	has = x.split('-');
	hasil = has[2]+"-"+has[1]+"-"+has[0];
	return hasil;
}